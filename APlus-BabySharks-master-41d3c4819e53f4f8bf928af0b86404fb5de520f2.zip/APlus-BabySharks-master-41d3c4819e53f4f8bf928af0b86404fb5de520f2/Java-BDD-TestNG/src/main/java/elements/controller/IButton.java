package elements.controller;

public interface IButton extends IElement {

    void mouseClick();

}