package utilities;

public class Contants {

    public static final int TIMEOUT_SECOND = 120;

}

